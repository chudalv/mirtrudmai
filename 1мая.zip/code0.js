gdjs.MainCode = {};
gdjs.MainCode.GDPlayerObjects1_1final = [];

gdjs.MainCode.GDPlayerObjects1= [];
gdjs.MainCode.GDPlayerObjects2= [];
gdjs.MainCode.GDPlayerObjects3= [];
gdjs.MainCode.GDPlayerObjects4= [];
gdjs.MainCode.GDPlayerObjects5= [];
gdjs.MainCode.GDPlatform1Objects1= [];
gdjs.MainCode.GDPlatform1Objects2= [];
gdjs.MainCode.GDPlatform1Objects3= [];
gdjs.MainCode.GDPlatform1Objects4= [];
gdjs.MainCode.GDPlatform1Objects5= [];
gdjs.MainCode.GDPlatform2Objects1= [];
gdjs.MainCode.GDPlatform2Objects2= [];
gdjs.MainCode.GDPlatform2Objects3= [];
gdjs.MainCode.GDPlatform2Objects4= [];
gdjs.MainCode.GDPlatform2Objects5= [];
gdjs.MainCode.GDPlatform3Objects1= [];
gdjs.MainCode.GDPlatform3Objects2= [];
gdjs.MainCode.GDPlatform3Objects3= [];
gdjs.MainCode.GDPlatform3Objects4= [];
gdjs.MainCode.GDPlatform3Objects5= [];
gdjs.MainCode.GDPlatform4Objects1= [];
gdjs.MainCode.GDPlatform4Objects2= [];
gdjs.MainCode.GDPlatform4Objects3= [];
gdjs.MainCode.GDPlatform4Objects4= [];
gdjs.MainCode.GDPlatform4Objects5= [];
gdjs.MainCode.GDDoorObjects1= [];
gdjs.MainCode.GDDoorObjects2= [];
gdjs.MainCode.GDDoorObjects3= [];
gdjs.MainCode.GDDoorObjects4= [];
gdjs.MainCode.GDDoorObjects5= [];
gdjs.MainCode.GDLadderObjects1= [];
gdjs.MainCode.GDLadderObjects2= [];
gdjs.MainCode.GDLadderObjects3= [];
gdjs.MainCode.GDLadderObjects4= [];
gdjs.MainCode.GDLadderObjects5= [];
gdjs.MainCode.GDMonsterObjects1= [];
gdjs.MainCode.GDMonsterObjects2= [];
gdjs.MainCode.GDMonsterObjects3= [];
gdjs.MainCode.GDMonsterObjects4= [];
gdjs.MainCode.GDMonsterObjects5= [];
gdjs.MainCode.GDFlyObjects1= [];
gdjs.MainCode.GDFlyObjects2= [];
gdjs.MainCode.GDFlyObjects3= [];
gdjs.MainCode.GDFlyObjects4= [];
gdjs.MainCode.GDFlyObjects5= [];
gdjs.MainCode.GDCoinObjects1= [];
gdjs.MainCode.GDCoinObjects2= [];
gdjs.MainCode.GDCoinObjects3= [];
gdjs.MainCode.GDCoinObjects4= [];
gdjs.MainCode.GDCoinObjects5= [];
gdjs.MainCode.GDMonsterParticlesObjects1= [];
gdjs.MainCode.GDMonsterParticlesObjects2= [];
gdjs.MainCode.GDMonsterParticlesObjects3= [];
gdjs.MainCode.GDMonsterParticlesObjects4= [];
gdjs.MainCode.GDMonsterParticlesObjects5= [];
gdjs.MainCode.GDCoinParticlesObjects1= [];
gdjs.MainCode.GDCoinParticlesObjects2= [];
gdjs.MainCode.GDCoinParticlesObjects3= [];
gdjs.MainCode.GDCoinParticlesObjects4= [];
gdjs.MainCode.GDCoinParticlesObjects5= [];
gdjs.MainCode.GDDoorParticlesObjects1= [];
gdjs.MainCode.GDDoorParticlesObjects2= [];
gdjs.MainCode.GDDoorParticlesObjects3= [];
gdjs.MainCode.GDDoorParticlesObjects4= [];
gdjs.MainCode.GDDoorParticlesObjects5= [];
gdjs.MainCode.GDGrassParticleObjects1= [];
gdjs.MainCode.GDGrassParticleObjects2= [];
gdjs.MainCode.GDGrassParticleObjects3= [];
gdjs.MainCode.GDGrassParticleObjects4= [];
gdjs.MainCode.GDGrassParticleObjects5= [];
gdjs.MainCode.GDPlayerSpawnObjects1= [];
gdjs.MainCode.GDPlayerSpawnObjects2= [];
gdjs.MainCode.GDPlayerSpawnObjects3= [];
gdjs.MainCode.GDPlayerSpawnObjects4= [];
gdjs.MainCode.GDPlayerSpawnObjects5= [];
gdjs.MainCode.GDScoreTextObjects1= [];
gdjs.MainCode.GDScoreTextObjects2= [];
gdjs.MainCode.GDScoreTextObjects3= [];
gdjs.MainCode.GDScoreTextObjects4= [];
gdjs.MainCode.GDScoreTextObjects5= [];
gdjs.MainCode.GDDPadBottomObjects1= [];
gdjs.MainCode.GDDPadBottomObjects2= [];
gdjs.MainCode.GDDPadBottomObjects3= [];
gdjs.MainCode.GDDPadBottomObjects4= [];
gdjs.MainCode.GDDPadBottomObjects5= [];
gdjs.MainCode.GDDPadTopObjects1= [];
gdjs.MainCode.GDDPadTopObjects2= [];
gdjs.MainCode.GDDPadTopObjects3= [];
gdjs.MainCode.GDDPadTopObjects4= [];
gdjs.MainCode.GDDPadTopObjects5= [];
gdjs.MainCode.GDDPadRightObjects1= [];
gdjs.MainCode.GDDPadRightObjects2= [];
gdjs.MainCode.GDDPadRightObjects3= [];
gdjs.MainCode.GDDPadRightObjects4= [];
gdjs.MainCode.GDDPadRightObjects5= [];
gdjs.MainCode.GDDPadLeftObjects1= [];
gdjs.MainCode.GDDPadLeftObjects2= [];
gdjs.MainCode.GDDPadLeftObjects3= [];
gdjs.MainCode.GDDPadLeftObjects4= [];
gdjs.MainCode.GDDPadLeftObjects5= [];
gdjs.MainCode.GDJumpButtonObjects1= [];
gdjs.MainCode.GDJumpButtonObjects2= [];
gdjs.MainCode.GDJumpButtonObjects3= [];
gdjs.MainCode.GDJumpButtonObjects4= [];
gdjs.MainCode.GDJumpButtonObjects5= [];
gdjs.MainCode.GDBackgroundPlantsObjects1= [];
gdjs.MainCode.GDBackgroundPlantsObjects2= [];
gdjs.MainCode.GDBackgroundPlantsObjects3= [];
gdjs.MainCode.GDBackgroundPlantsObjects4= [];
gdjs.MainCode.GDBackgroundPlantsObjects5= [];
gdjs.MainCode.GDBoundaryObjects1= [];
gdjs.MainCode.GDBoundaryObjects2= [];
gdjs.MainCode.GDBoundaryObjects3= [];
gdjs.MainCode.GDBoundaryObjects4= [];
gdjs.MainCode.GDBoundaryObjects5= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects1= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects2= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects3= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects4= [];
gdjs.MainCode.GDBoundaryJumpThroughObjects5= [];
gdjs.MainCode.GDMoonObjects1= [];
gdjs.MainCode.GDMoonObjects2= [];
gdjs.MainCode.GDMoonObjects3= [];
gdjs.MainCode.GDMoonObjects4= [];
gdjs.MainCode.GDMoonObjects5= [];
gdjs.MainCode.GDEndScreenBackgroundObjects1= [];
gdjs.MainCode.GDEndScreenBackgroundObjects2= [];
gdjs.MainCode.GDEndScreenBackgroundObjects3= [];
gdjs.MainCode.GDEndScreenBackgroundObjects4= [];
gdjs.MainCode.GDEndScreenBackgroundObjects5= [];
gdjs.MainCode.GDEndScreenHeaderObjects1= [];
gdjs.MainCode.GDEndScreenHeaderObjects2= [];
gdjs.MainCode.GDEndScreenHeaderObjects3= [];
gdjs.MainCode.GDEndScreenHeaderObjects4= [];
gdjs.MainCode.GDEndScreenHeaderObjects5= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects1= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects2= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects3= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects4= [];
gdjs.MainCode.GDEndScreenSubHeaderObjects5= [];
gdjs.MainCode.GDEndScreenBestTextObjects1= [];
gdjs.MainCode.GDEndScreenBestTextObjects2= [];
gdjs.MainCode.GDEndScreenBestTextObjects3= [];
gdjs.MainCode.GDEndScreenBestTextObjects4= [];
gdjs.MainCode.GDEndScreenBestTextObjects5= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects1= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects2= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects3= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects4= [];
gdjs.MainCode.GDEndScreenChallengeTextObjects5= [];
gdjs.MainCode.GDEndScreenRetryTextObjects1= [];
gdjs.MainCode.GDEndScreenRetryTextObjects2= [];
gdjs.MainCode.GDEndScreenRetryTextObjects3= [];
gdjs.MainCode.GDEndScreenRetryTextObjects4= [];
gdjs.MainCode.GDEndScreenRetryTextObjects5= [];
gdjs.MainCode.GDNewSpriteObjects1= [];
gdjs.MainCode.GDNewSpriteObjects2= [];
gdjs.MainCode.GDNewSpriteObjects3= [];
gdjs.MainCode.GDNewSpriteObjects4= [];
gdjs.MainCode.GDNewSpriteObjects5= [];
gdjs.MainCode.GDNewSprite2Objects1= [];
gdjs.MainCode.GDNewSprite2Objects2= [];
gdjs.MainCode.GDNewSprite2Objects3= [];
gdjs.MainCode.GDNewSprite2Objects4= [];
gdjs.MainCode.GDNewSprite2Objects5= [];

gdjs.MainCode.conditionTrue_0 = {val:false};
gdjs.MainCode.condition0IsTrue_0 = {val:false};
gdjs.MainCode.condition1IsTrue_0 = {val:false};
gdjs.MainCode.condition2IsTrue_0 = {val:false};
gdjs.MainCode.condition3IsTrue_0 = {val:false};
gdjs.MainCode.condition4IsTrue_0 = {val:false};
gdjs.MainCode.conditionTrue_1 = {val:false};
gdjs.MainCode.condition0IsTrue_1 = {val:false};
gdjs.MainCode.condition1IsTrue_1 = {val:false};
gdjs.MainCode.condition2IsTrue_1 = {val:false};
gdjs.MainCode.condition3IsTrue_1 = {val:false};
gdjs.MainCode.condition4IsTrue_1 = {val:false};


gdjs.MainCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets.mp3", true, 30, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.MainCode.GDBackgroundPlantsObjects1);
{for(var i = 0, len = gdjs.MainCode.GDBackgroundPlantsObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDBackgroundPlantsObjects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 3);
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadLeftObjects2Objects = Hashtable.newFrom({"DPadLeft": gdjs.MainCode.GDDPadLeftObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadRightObjects2Objects = Hashtable.newFrom({"DPadRight": gdjs.MainCode.GDDPadRightObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadTopObjects2Objects = Hashtable.newFrom({"DPadTop": gdjs.MainCode.GDDPadTopObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadBottomObjects2Objects = Hashtable.newFrom({"DPadBottom": gdjs.MainCode.GDDPadBottomObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs.MainCode.GDJumpButtonObjects1});gdjs.MainCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DPadLeft"), gdjs.MainCode.GDDPadLeftObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadLeftObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DPadRight"), gdjs.MainCode.GDDPadRightObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadRightObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DPadTop"), gdjs.MainCode.GDDPadTopObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadTopObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Up");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Ladder");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DPadBottom"), gdjs.MainCode.GDDPadBottomObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDPadBottomObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.MainCode.GDJumpButtonObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


};gdjs.MainCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DPadBottom"), gdjs.MainCode.GDDPadBottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("DPadLeft"), gdjs.MainCode.GDDPadLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("DPadRight"), gdjs.MainCode.GDDPadRightObjects2);
gdjs.copyArray(runtimeScene.getObjects("DPadTop"), gdjs.MainCode.GDDPadTopObjects2);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.MainCode.GDJumpButtonObjects2);
{for(var i = 0, len = gdjs.MainCode.GDDPadBottomObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDPadBottomObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDDPadTopObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDPadTopObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDDPadRightObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDPadRightObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDDPadLeftObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDDPadLeftObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainCode.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDJumpButtonObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


{

{ //Subevents
gdjs.MainCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setAnimationName("Jump");
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setAnimationName("Climb");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].playAnimation();
}
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setAnimationName("Run");
}
}}

}


{

/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setAnimationName("Fall");
}
}}

}


};gdjs.MainCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isOnLadder() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].pauseAnimation();
}
}}

}


{

/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setAnimationName("Idle");
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDGrassParticleObjects1Objects = Hashtable.newFrom({"GrassParticle": gdjs.MainCode.GDGrassParticleObjects1});gdjs.MainCode.eventsList5 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainCode.GDPlayerObjects1 */

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.GDPlayerObjects1_1final.length = 0;gdjs.MainCode.condition0IsTrue_1.val = false;
gdjs.MainCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects1, gdjs.MainCode.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getAnimationFrame() == 4 ) {
        gdjs.MainCode.condition0IsTrue_1.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;if( gdjs.MainCode.condition0IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.MainCode.GDPlayerObjects1_1final.indexOf(gdjs.MainCode.GDPlayerObjects2[j]) === -1 )
            gdjs.MainCode.GDPlayerObjects1_1final.push(gdjs.MainCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects1, gdjs.MainCode.GDPlayerObjects2);

for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getAnimationFrame() == 14 ) {
        gdjs.MainCode.condition1IsTrue_1.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;if( gdjs.MainCode.condition1IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.MainCode.GDPlayerObjects1_1final.indexOf(gdjs.MainCode.GDPlayerObjects2[j]) === -1 )
            gdjs.MainCode.GDPlayerObjects1_1final.push(gdjs.MainCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainCode.GDPlayerObjects1_1final, gdjs.MainCode.GDPlayerObjects1);
}
}
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10765556);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects1 */
gdjs.MainCode.GDGrassParticleObjects1.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets/audio/grass.mp3", 1, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), gdjs.randomFloatInRange(0.7, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDGrassParticleObjects1Objects, (( gdjs.MainCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects1[0].getPointX("GrassParticle")), (( gdjs.MainCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.MainCode.GDPlayerObjects1[0].getPointY("GrassParticle")), "");
}{for(var i = 0, len = gdjs.MainCode.GDGrassParticleObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDGrassParticleObjects1[i].setZOrder(-(1));
}
}}

}


};gdjs.MainCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10760380);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10761172);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition1IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10762484);
}
}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), 1);
}}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects1[i].isCurrentAnimationName("Run") ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects1[k] = gdjs.MainCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects1.length = k;}}
if (gdjs.MainCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), false);
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].getBehavior("CheckpointPlayer").ToSpawn((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "death.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects2[i].getCenterYInScene() > 540 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


gdjs.MainCode.eventsList6(runtimeScene);
}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects1});gdjs.MainCode.eventsList8 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen"));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects1);
{gdjs.evtsExt__SimpleSmoothCameraFollow__SmoothCameraFollow.func(runtimeScene, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects1Objects, 0.15, 0.05, "", 0, 124, -(120), 2113, 542, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterObjects2Objects = Hashtable.newFrom({"Monster": gdjs.MainCode.GDMonsterObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterParticlesObjects4Objects = Hashtable.newFrom({"MonsterParticles": gdjs.MainCode.GDMonsterParticlesObjects4});gdjs.MainCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects4);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects4[k] = gdjs.MainCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects4.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainCode.GDMonsterObjects3, gdjs.MainCode.GDMonsterObjects4);

/* Reuse gdjs.MainCode.GDPlayerObjects4 */
gdjs.MainCode.GDMonsterParticlesObjects4.length = 0;

{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{runtimeScene.getVariables().getFromIndex(0).add(50);
}{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterParticlesObjects4Objects, (( gdjs.MainCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.MainCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.MainCode.GDMonsterObjects4[0].getCenterYInScene()), "");
}}

}


{

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects3[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDMonsterObjects2, gdjs.MainCode.GDMonsterObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects3[i].isCurrentAnimationName("NoFire") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects3[k] = gdjs.MainCode.GDMonsterObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects3.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.MainCode.GDMonsterObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].isCurrentAnimationName("Fire") ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDMonsterObjects2Objects, false, runtimeScene, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].resetTimer("Fire");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Fire") >= 2 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].toggleVariableBoolean(gdjs.MainCode.GDMonsterObjects2[i].getVariables().getFromIndex(0));
}
}{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].resetTimer("Fire");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects2[i].getVariableBoolean(gdjs.MainCode.GDMonsterObjects2[i].getVariables().getFromIndex(0), false) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects2[k] = gdjs.MainCode.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects2[i].setAnimationName("NoFire");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.MainCode.GDMonsterObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDMonsterObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDMonsterObjects1[i].getVariableBoolean(gdjs.MainCode.GDMonsterObjects1[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDMonsterObjects1[k] = gdjs.MainCode.GDMonsterObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDMonsterObjects1.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDMonsterObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDMonsterObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDMonsterObjects1[i].setAnimationName("Fire");
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.MainCode.GDFlyObjects2});gdjs.MainCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainCode.GDFlyObjects2, gdjs.MainCode.GDFlyObjects3);

gdjs.copyArray(gdjs.MainCode.GDPlayerObjects2, gdjs.MainCode.GDPlayerObjects3);


gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects3[k] = gdjs.MainCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects3.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects3.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects3[i].getVariableBoolean(gdjs.MainCode.GDFlyObjects3[i].getVariables().getFromIndex(0), false) ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects3[k] = gdjs.MainCode.GDFlyObjects3[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects3.length = k;}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDFlyObjects3 */
/* Reuse gdjs.MainCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].setVariableBoolean(gdjs.MainCode.GDFlyObjects3[i].getVariables().get("falling"), true);
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{runtimeScene.getVariables().getFromIndex(0).add(50);
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), 1);
}{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].setVariableBoolean(gdjs.MainCode.GDFlyObjects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].getBehavior("RectangularMovement").SetVerticalSpeed(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

/* Reuse gdjs.MainCode.GDFlyObjects2 */
/* Reuse gdjs.MainCode.GDPlayerObjects2 */

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.MainCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDPlayerObjects2[k] = gdjs.MainCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDPlayerObjects2.length = k;}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects2[i].getVariableBoolean(gdjs.MainCode.GDFlyObjects2[i].getVariables().get("falling"), false) ) {
        gdjs.MainCode.condition1IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects2[k] = gdjs.MainCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects2.length = k;}}
if (gdjs.MainCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].setVariableBoolean(gdjs.MainCode.GDPlayerObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


};gdjs.MainCode.eventsList13 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10781204);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainCode.GDFlyObjects2, gdjs.MainCode.GDFlyObjects3);

{for(var i = 0, len = gdjs.MainCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(300, 0, 0, 30, 0.3, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


{
/* Reuse gdjs.MainCode.GDFlyObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects2[i].getBehavior("RectangularMovement").SetCenterY((gdjs.MainCode.GDFlyObjects2[i].getBehavior("RectangularMovement").CenterY((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + 150 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainCode.eventsList14 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.MainCode.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDFlyObjects2Objects, false, runtimeScene, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.MainCode.GDFlyObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects2[i].getVariableBoolean(gdjs.MainCode.GDFlyObjects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects2[k] = gdjs.MainCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects2.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainCode.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.MainCode.GDFlyObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDFlyObjects1[i].getCenterYInScene() > 542 ) {
        gdjs.MainCode.condition0IsTrue_0.val = true;
        gdjs.MainCode.GDFlyObjects1[k] = gdjs.MainCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDFlyObjects1.length = k;}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDFlyObjects1 */
{for(var i = 0, len = gdjs.MainCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.MainCode.GDCoinObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.MainCode.GDCoinParticlesObjects2});gdjs.MainCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.MainCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinObjects2Objects, false, runtimeScene, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDCoinObjects2 */
gdjs.MainCode.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDCoinParticlesObjects2Objects, (( gdjs.MainCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.MainCode.GDCoinObjects2.length === 0 ) ? 0 :gdjs.MainCode.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.MainCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 100, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.MainCode.GDScoreTextObjects1);
{for(var i = 0, len = gdjs.MainCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDScoreTextObjects1[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.MainCode.GDDoorObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.MainCode.GDPlayerObjects2});gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.MainCode.GDDoorObjects2});gdjs.MainCode.eventsList16 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= 950;
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.MainCode.GDEndScreenChallengeTextObjects3);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenChallengeTextObjects3.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenChallengeTextObjects3[i].hide();
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < 950;
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.MainCode.GDEndScreenBestTextObjects2);
{for(var i = 0, len = gdjs.MainCode.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBestTextObjects2[i].hide();
}
}}

}


};gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects1Objects = Hashtable.newFrom({"EndScreenRetryText": gdjs.MainCode.GDEndScreenRetryTextObjects1});gdjs.MainCode.eventsList17 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "doorSound.ogg", 0, true, 100, 1);
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.MainCode.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDoorObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, 0, 20, 750, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.MainCode.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.MainCode.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenBackgroundObjects2[i].setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.MainCode.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.MainCode.GDPlayerObjects2);

gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDPlayerObjects2Objects, gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDDoorObjects2Objects, false, runtimeScene, false);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.MainCode.GDEndScreenSubHeaderObjects2);
/* Reuse gdjs.MainCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.MainCode.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDEndScreenSubHeaderObjects2[i].setString("You got " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0)) + " points!");
}
}{for(var i = 0, len = gdjs.MainCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}
{ //Subevents
gdjs.MainCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.MainCode.GDEndScreenRetryTextObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
gdjs.MainCode.condition3IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDEndScreenRetryTextObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition2IsTrue_0;
gdjs.MainCode.condition0IsTrue_1.val = false;
gdjs.MainCode.condition1IsTrue_1.val = false;
{
gdjs.MainCode.condition0IsTrue_1.val = gdjs.evtTools.systemInfo.isMobile();
if( gdjs.MainCode.condition0IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainCode.condition1IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if( gdjs.MainCode.condition1IsTrue_1.val ) {
    gdjs.MainCode.conditionTrue_1.val = true;
}
}
{
}
}
}if ( gdjs.MainCode.condition2IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition3IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10793156);
}
}}
}
}
if (gdjs.MainCode.condition3IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main", false);
}}

}


};gdjs.MainCode.eventsList18 = function(runtimeScene) {

{


{
}

}


{


{
}

}


};gdjs.MainCode.eventsList19 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition0IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10794108);
}
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint.mp3", false, 100, 1);
}
{ //Subevents
gdjs.MainCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList20 = function(runtimeScene) {

{



}


{


gdjs.MainCode.eventsList0(runtimeScene);
}


{


gdjs.MainCode.eventsList2(runtimeScene);
}


{


gdjs.MainCode.eventsList7(runtimeScene);
}


{


gdjs.MainCode.eventsList8(runtimeScene);
}


{


gdjs.MainCode.eventsList11(runtimeScene);
}


{


gdjs.MainCode.eventsList14(runtimeScene);
}


{


gdjs.MainCode.eventsList15(runtimeScene);
}


{


gdjs.MainCode.eventsList17(runtimeScene);
}


{


gdjs.MainCode.eventsList19(runtimeScene);
}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDPlayerObjects1.length = 0;
gdjs.MainCode.GDPlayerObjects2.length = 0;
gdjs.MainCode.GDPlayerObjects3.length = 0;
gdjs.MainCode.GDPlayerObjects4.length = 0;
gdjs.MainCode.GDPlayerObjects5.length = 0;
gdjs.MainCode.GDPlatform1Objects1.length = 0;
gdjs.MainCode.GDPlatform1Objects2.length = 0;
gdjs.MainCode.GDPlatform1Objects3.length = 0;
gdjs.MainCode.GDPlatform1Objects4.length = 0;
gdjs.MainCode.GDPlatform1Objects5.length = 0;
gdjs.MainCode.GDPlatform2Objects1.length = 0;
gdjs.MainCode.GDPlatform2Objects2.length = 0;
gdjs.MainCode.GDPlatform2Objects3.length = 0;
gdjs.MainCode.GDPlatform2Objects4.length = 0;
gdjs.MainCode.GDPlatform2Objects5.length = 0;
gdjs.MainCode.GDPlatform3Objects1.length = 0;
gdjs.MainCode.GDPlatform3Objects2.length = 0;
gdjs.MainCode.GDPlatform3Objects3.length = 0;
gdjs.MainCode.GDPlatform3Objects4.length = 0;
gdjs.MainCode.GDPlatform3Objects5.length = 0;
gdjs.MainCode.GDPlatform4Objects1.length = 0;
gdjs.MainCode.GDPlatform4Objects2.length = 0;
gdjs.MainCode.GDPlatform4Objects3.length = 0;
gdjs.MainCode.GDPlatform4Objects4.length = 0;
gdjs.MainCode.GDPlatform4Objects5.length = 0;
gdjs.MainCode.GDDoorObjects1.length = 0;
gdjs.MainCode.GDDoorObjects2.length = 0;
gdjs.MainCode.GDDoorObjects3.length = 0;
gdjs.MainCode.GDDoorObjects4.length = 0;
gdjs.MainCode.GDDoorObjects5.length = 0;
gdjs.MainCode.GDLadderObjects1.length = 0;
gdjs.MainCode.GDLadderObjects2.length = 0;
gdjs.MainCode.GDLadderObjects3.length = 0;
gdjs.MainCode.GDLadderObjects4.length = 0;
gdjs.MainCode.GDLadderObjects5.length = 0;
gdjs.MainCode.GDMonsterObjects1.length = 0;
gdjs.MainCode.GDMonsterObjects2.length = 0;
gdjs.MainCode.GDMonsterObjects3.length = 0;
gdjs.MainCode.GDMonsterObjects4.length = 0;
gdjs.MainCode.GDMonsterObjects5.length = 0;
gdjs.MainCode.GDFlyObjects1.length = 0;
gdjs.MainCode.GDFlyObjects2.length = 0;
gdjs.MainCode.GDFlyObjects3.length = 0;
gdjs.MainCode.GDFlyObjects4.length = 0;
gdjs.MainCode.GDFlyObjects5.length = 0;
gdjs.MainCode.GDCoinObjects1.length = 0;
gdjs.MainCode.GDCoinObjects2.length = 0;
gdjs.MainCode.GDCoinObjects3.length = 0;
gdjs.MainCode.GDCoinObjects4.length = 0;
gdjs.MainCode.GDCoinObjects5.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects1.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects2.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects3.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects4.length = 0;
gdjs.MainCode.GDMonsterParticlesObjects5.length = 0;
gdjs.MainCode.GDCoinParticlesObjects1.length = 0;
gdjs.MainCode.GDCoinParticlesObjects2.length = 0;
gdjs.MainCode.GDCoinParticlesObjects3.length = 0;
gdjs.MainCode.GDCoinParticlesObjects4.length = 0;
gdjs.MainCode.GDCoinParticlesObjects5.length = 0;
gdjs.MainCode.GDDoorParticlesObjects1.length = 0;
gdjs.MainCode.GDDoorParticlesObjects2.length = 0;
gdjs.MainCode.GDDoorParticlesObjects3.length = 0;
gdjs.MainCode.GDDoorParticlesObjects4.length = 0;
gdjs.MainCode.GDDoorParticlesObjects5.length = 0;
gdjs.MainCode.GDGrassParticleObjects1.length = 0;
gdjs.MainCode.GDGrassParticleObjects2.length = 0;
gdjs.MainCode.GDGrassParticleObjects3.length = 0;
gdjs.MainCode.GDGrassParticleObjects4.length = 0;
gdjs.MainCode.GDGrassParticleObjects5.length = 0;
gdjs.MainCode.GDPlayerSpawnObjects1.length = 0;
gdjs.MainCode.GDPlayerSpawnObjects2.length = 0;
gdjs.MainCode.GDPlayerSpawnObjects3.length = 0;
gdjs.MainCode.GDPlayerSpawnObjects4.length = 0;
gdjs.MainCode.GDPlayerSpawnObjects5.length = 0;
gdjs.MainCode.GDScoreTextObjects1.length = 0;
gdjs.MainCode.GDScoreTextObjects2.length = 0;
gdjs.MainCode.GDScoreTextObjects3.length = 0;
gdjs.MainCode.GDScoreTextObjects4.length = 0;
gdjs.MainCode.GDScoreTextObjects5.length = 0;
gdjs.MainCode.GDDPadBottomObjects1.length = 0;
gdjs.MainCode.GDDPadBottomObjects2.length = 0;
gdjs.MainCode.GDDPadBottomObjects3.length = 0;
gdjs.MainCode.GDDPadBottomObjects4.length = 0;
gdjs.MainCode.GDDPadBottomObjects5.length = 0;
gdjs.MainCode.GDDPadTopObjects1.length = 0;
gdjs.MainCode.GDDPadTopObjects2.length = 0;
gdjs.MainCode.GDDPadTopObjects3.length = 0;
gdjs.MainCode.GDDPadTopObjects4.length = 0;
gdjs.MainCode.GDDPadTopObjects5.length = 0;
gdjs.MainCode.GDDPadRightObjects1.length = 0;
gdjs.MainCode.GDDPadRightObjects2.length = 0;
gdjs.MainCode.GDDPadRightObjects3.length = 0;
gdjs.MainCode.GDDPadRightObjects4.length = 0;
gdjs.MainCode.GDDPadRightObjects5.length = 0;
gdjs.MainCode.GDDPadLeftObjects1.length = 0;
gdjs.MainCode.GDDPadLeftObjects2.length = 0;
gdjs.MainCode.GDDPadLeftObjects3.length = 0;
gdjs.MainCode.GDDPadLeftObjects4.length = 0;
gdjs.MainCode.GDDPadLeftObjects5.length = 0;
gdjs.MainCode.GDJumpButtonObjects1.length = 0;
gdjs.MainCode.GDJumpButtonObjects2.length = 0;
gdjs.MainCode.GDJumpButtonObjects3.length = 0;
gdjs.MainCode.GDJumpButtonObjects4.length = 0;
gdjs.MainCode.GDJumpButtonObjects5.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects1.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects2.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects3.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects4.length = 0;
gdjs.MainCode.GDBackgroundPlantsObjects5.length = 0;
gdjs.MainCode.GDBoundaryObjects1.length = 0;
gdjs.MainCode.GDBoundaryObjects2.length = 0;
gdjs.MainCode.GDBoundaryObjects3.length = 0;
gdjs.MainCode.GDBoundaryObjects4.length = 0;
gdjs.MainCode.GDBoundaryObjects5.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.MainCode.GDBoundaryJumpThroughObjects5.length = 0;
gdjs.MainCode.GDMoonObjects1.length = 0;
gdjs.MainCode.GDMoonObjects2.length = 0;
gdjs.MainCode.GDMoonObjects3.length = 0;
gdjs.MainCode.GDMoonObjects4.length = 0;
gdjs.MainCode.GDMoonObjects5.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects1.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects2.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects3.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects4.length = 0;
gdjs.MainCode.GDEndScreenBackgroundObjects5.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects1.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects2.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects3.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects4.length = 0;
gdjs.MainCode.GDEndScreenHeaderObjects5.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.MainCode.GDEndScreenSubHeaderObjects5.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenBestTextObjects5.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenChallengeTextObjects5.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects1.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects2.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects3.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects4.length = 0;
gdjs.MainCode.GDEndScreenRetryTextObjects5.length = 0;
gdjs.MainCode.GDNewSpriteObjects1.length = 0;
gdjs.MainCode.GDNewSpriteObjects2.length = 0;
gdjs.MainCode.GDNewSpriteObjects3.length = 0;
gdjs.MainCode.GDNewSpriteObjects4.length = 0;
gdjs.MainCode.GDNewSpriteObjects5.length = 0;
gdjs.MainCode.GDNewSprite2Objects1.length = 0;
gdjs.MainCode.GDNewSprite2Objects2.length = 0;
gdjs.MainCode.GDNewSprite2Objects3.length = 0;
gdjs.MainCode.GDNewSprite2Objects4.length = 0;
gdjs.MainCode.GDNewSprite2Objects5.length = 0;

gdjs.MainCode.eventsList20(runtimeScene);
return;

}

gdjs['MainCode'] = gdjs.MainCode;
